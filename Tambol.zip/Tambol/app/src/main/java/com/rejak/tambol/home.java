package com.rejak.tambol;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.content.Intent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

public class home extends AppCompatActivity implements View.OnClickListener{
    private Button btn_profil;
    private Button btn_motor;
    private Button btn_mobil;
    private Button btn_pesanan;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        btn_profil = findViewById(R.id.btn_profil);
        btn_profil.setOnClickListener(this);
        btn_motor = findViewById(R.id.btn_motor);
        btn_motor.setOnClickListener(this);
        btn_mobil = findViewById(R.id.btn_mobil);
        btn_mobil.setOnClickListener(this);
        btn_pesanan = findViewById(R.id.btn_pesanan);
        btn_pesanan.setOnClickListener(this);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.optionmenu, menu);
        //getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;

    }

    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId()==R.id.about){
            openDialog();
        } else if (item.getItemId() == R.id.help) {
            startActivity(new Intent(this, help.class));
        }

        return true;
    }

    public void openDialog() {
        exampledialog exampleDialog = new exampledialog();
        exampleDialog.show(getSupportFragmentManager(), "example dialog");
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_profil:
                Intent profil = new Intent(home.this, profil.class);
                startActivity(profil);
                break;
            case R.id.btn_motor:
                Intent motor = new Intent(home.this, motor.class);
                startActivity(motor);
                break;
            case R.id.btn_mobil:
                Intent mobil = new Intent(home.this, mobil.class);
                startActivity(mobil);
                break;
            case R.id.btn_pesanan:
                Intent pesanan = new Intent(home.this, pesanan.class);
                startActivity(pesanan);
                break;
        }
    }

}
