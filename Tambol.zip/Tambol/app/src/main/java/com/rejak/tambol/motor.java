package com.rejak.tambol;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.firebase.firestore.FirebaseFirestore;

public class motor extends AppCompatActivity implements View.OnClickListener{
    private Button btn_detail;
    private FirebaseFirestore firebaseFirestore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_motor);
        btn_detail = findViewById(R.id.btn_detail);
        btn_detail.setOnClickListener(this);
        firebaseFirestore=FirebaseFirestore.getInstance();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_detail:
                Intent detail = new Intent(motor.this, detail.class);
                startActivity(detail);
                break;

        }
    }
}
