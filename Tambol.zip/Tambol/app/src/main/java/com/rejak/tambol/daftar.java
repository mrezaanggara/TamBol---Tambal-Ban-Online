package com.rejak.tambol;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class daftar extends AppCompatActivity implements View.OnClickListener {
    EditText mAddress,mPassword,mEmail,mNomor,mNama;
    Button daftar,buat2;
    FirebaseAuth fAuth;
    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daftar);

        mAddress = findViewById(R.id.mAddress);
        mEmail = findViewById(R.id.mEmail);
        mPassword = findViewById(R.id.mPassword);
        mNomor = findViewById(R.id.mNomor);
        mNama = findViewById(R.id.mNama);
        daftar = findViewById(R.id.daftar);
        buat2 = findViewById(R.id.buat2);
        buat2.setOnClickListener(this);

        fAuth = FirebaseAuth.getInstance();
        progressBar = findViewById(R.id.progressBar);

        if(fAuth.getCurrentUser() !=null){
            startActivity(new Intent(getApplicationContext(),home.class));
        }

        daftar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = mEmail.getText().toString().trim();
                String password = mPassword.getText().toString().trim();

                if (TextUtils.isEmpty(email)) {
                    mEmail.setError("Email harus diisi!");
                    return;
                }
                if (TextUtils.isEmpty(password)) {
                    mPassword.setError("Password harus diisi!");
                    return;
                }
                if (password.length() < 6) {
                    mPassword.setError("Password harus lebih dari 6 karakter!");
                    return;
                }

                progressBar.setVisibility(View.VISIBLE);

                // register akun di firebase

                fAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()) {
                            Toast.makeText(daftar.this, "Akun berhasil dibuat", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(getApplicationContext(),home.class));
                        }else{
                            Toast.makeText(daftar.this,"Error!"+ task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.buat2:
                Intent Login = new Intent(daftar.this, com.rejak.tambol.Login.class);
                startActivity(Login);
                break;

        }

    }
}
